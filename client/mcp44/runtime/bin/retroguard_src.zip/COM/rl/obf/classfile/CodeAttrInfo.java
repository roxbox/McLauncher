/* ===========================================================================
 * $RCSfile: CodeAttrInfo.java,v $
 * ===========================================================================
 *
 * RetroGuard -- an obfuscation package for Java classfiles.
 *
 * Copyright (c) 1998-2006 Mark Welsh (markw@retrologic.com)
 *
 * This program can be redistributed and/or modified under the terms of the
 * Version 2 of the GNU General Public License as published by the Free
 * Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 */

package COM.rl.obf.classfile;

import java.io.*;
import java.util.*;

import COM.rl.util.*;

/**
 * Representation of an attribute.
 * 
 * @author Mark Welsh
 */
public class CodeAttrInfo extends AttrInfo
{
    // Constants -------------------------------------------------------------
    @SuppressWarnings("hiding")
    public static final int CONSTANT_FIELD_SIZE = 12;


    // Fields ----------------------------------------------------------------
    private int u2maxStack;
    private int u2maxLocals;
    private int u4codeLength;
    private byte[] code;
    private List<ExceptionInfo> exceptionTable;
    protected List<AttrInfo> attributes;


    // Class Methods ---------------------------------------------------------
    /**
     * Number of bytes following an opcode
     * 
     * @param opcode
     */
    private static int opcodeBytes(int opcode)
    {
        switch (opcode)
        {
            case 0xAA:
            case 0xAB:
            case 0xC4:
                return -1; // variable length opcode
            case 0x10:
            case 0x12:
            case 0x15:
            case 0x16:
            case 0x17:
            case 0x18:
            case 0x19:
            case 0x36:
            case 0x37:
            case 0x38:
            case 0x39:
            case 0x3A:
            case 0xBC:
                return 1;
            case 0x11:
            case 0x13:
            case 0x14:
            case 0x84:
            case 0x99:
            case 0x9A:
            case 0x9B:
            case 0x9C:
            case 0x9D:
            case 0x9E:
            case 0x9F:
            case 0xA0:
            case 0xA1:
            case 0xA2:
            case 0xA3:
            case 0xA4:
            case 0xA5:
            case 0xA6:
            case 0xA7:
            case 0xA8:
            case 0xB2:
            case 0xB3:
            case 0xB4:
            case 0xB5:
            case 0xB6:
            case 0xB7:
            case 0xB8:
            case 0xBB:
            case 0xBD:
            case 0xC0:
            case 0xC1:
            case 0xC6:
            case 0xC7:
                return 2;
            case 0xC5:
                return 3;
            case 0xB9:
            case 0xBA:
            case 0xC8:
            case 0xC9:
                return 4;
            default:
                return 0;
        }
    }


    // Instance Methods ------------------------------------------------------
    /**
     * Constructor
     * 
     * @param cf
     * @param attrNameIndex
     * @param attrLength
     */
    protected CodeAttrInfo(ClassFile cf, int attrNameIndex, int attrLength)
    {
        super(cf, attrNameIndex, attrLength);
    }

    /**
     * Return the length in bytes of the attribute.
     */
    @Override
    protected int getAttrInfoLength()
    {
        int length = CodeAttrInfo.CONSTANT_FIELD_SIZE + this.u4codeLength
            + (this.exceptionTable.size() * ExceptionInfo.CONSTANT_FIELD_SIZE);
        for (AttrInfo at : this.attributes)
        {
            length += AttrInfo.CONSTANT_FIELD_SIZE + at.getAttrInfoLength();
        }
        return length;
    }

    /**
     * Return the String name of the attribute; over-ride this in sub-classes.
     */
    @Override
    protected String getAttrName()
    {
        return ClassConstants.ATTR_Code;
    }

    /**
     * Trim attributes from the classfile ('Code', 'Exceptions', 'ConstantValue' are preserved, all others except those in the
     * {@code List<String>} are killed).
     */
    @Override
    protected void trimAttrsExcept(List<String> keepAttrs)
    {
        // Traverse all attributes, removing all except those on 'keep' list
        List<AttrInfo> delAttrs = new ArrayList<AttrInfo>();
        for (AttrInfo at : this.attributes)
        {
            if (keepAttrs.contains(at.getAttrName()))
            {
                at.trimAttrsExcept(keepAttrs);
            }
            else
            {
                delAttrs.add(at);
            }
        }

        this.attributes.removeAll(delAttrs);
    }

    /**
     * Check for references in the 'info' data to the constant pool and mark them.
     * 
     * @throws ClassFileException
     */
    @Override
    protected void markUtf8RefsInInfo(ConstantPool pool) throws ClassFileException
    {
        for (AttrInfo at : this.attributes)
        {
            at.markUtf8Refs(pool);
        }
    }

    /**
     * Read the data following the header.
     * 
     * @throws IOException
     * @throws ClassFileException
     */
    @Override
    protected void readInfo(DataInput din) throws IOException, ClassFileException
    {
        this.u2maxStack = din.readUnsignedShort();
        this.u2maxLocals = din.readUnsignedShort();
        this.u4codeLength = din.readInt();
        this.code = new byte[this.u4codeLength];
        din.readFully(this.code);
        int u2exceptionTableLength = din.readUnsignedShort();
        this.exceptionTable = new ArrayList<ExceptionInfo>(u2exceptionTableLength);
        for (int i = 0; i < u2exceptionTableLength; i++)
        {
            this.exceptionTable.add(ExceptionInfo.create(din));
        }
        int u2attributesCount = din.readUnsignedShort();
        this.attributes = new ArrayList<AttrInfo>(u2attributesCount);
        for (int i = 0; i < u2attributesCount; i++)
        {
            this.attributes.add(AttrInfo.create(din, this.cf, AttrSource.CODE));
        }
    }

    /**
     * Export data following the header to a DataOutput stream.
     * 
     * @throws IOException
     * @throws ClassFileException
     */
    @Override
    public void writeInfo(DataOutput dout) throws IOException, ClassFileException
    {
        dout.writeShort(this.u2maxStack);
        dout.writeShort(this.u2maxLocals);
        dout.writeInt(this.u4codeLength);
        dout.write(this.code);
        dout.writeShort(this.exceptionTable.size());
        for (ExceptionInfo ex : this.exceptionTable)
        {
            ex.write(dout);
        }
        dout.writeShort(this.attributes.size());
        for (AttrInfo at : this.attributes)
        {
            at.write(dout);
        }
    }

    /**
     * Do necessary name remapping.
     * 
     * @throws ClassFileException
     */
    @Override
    protected void remap(ClassFile cf, NameMapper nm) throws ClassFileException
    {
        for (AttrInfo at : this.attributes)
        {
            at.remap(cf, nm);
        }
    }

    /**
     * Walk the code, finding .class and Class.forName to update.
     * 
     * @param cpToFlag
     * @throws ClassFileException
     */
    protected FlagHashtable walkFindClassStrings(FlagHashtable cpToFlag) throws ClassFileException
    {
        return this.walkClassStrings(cpToFlag, Collections.<Integer, Integer>emptyMap());
    }

    /**
     * Walk the code, updating .class and Class.forName strings.
     * 
     * @param cpUpdate
     * @throws ClassFileException
     */
    protected void walkUpdateClassStrings(Map<Integer, ?> cpUpdate) throws ClassFileException
    {
        this.walkClassStrings(null, cpUpdate);
    }

    /**
     * Walk the code, updating .class and Class.forName strings.
     * Note that class literals MyClass.class are stored directly in the constant pool in 1.5 (change from 1.4), not referenced
     * by Utf8 name, so .option MapClassString is not necessary for them.
     * Still needed for Class.forName("MyClass") though.
     * 
     * @param cpToFlag
     * @param cpUpdate
     * @throws ClassFileException
     */
    private FlagHashtable walkClassStrings(FlagHashtable cpToFlag, Map<Integer, ?> cpUpdate) throws ClassFileException
    {
        int opcodePrev = -1;
        int ldcIndex = -1;
        for (int i = 0; i < this.code.length; i++)
        {
            int opcode = this.code[i] & 0xFF;
            if ((opcode == 0x12) && ((i + 1) < this.code.length)) // ldc
            {
                ldcIndex = this.code[i + 1] & 0xFF;
                CpInfo ldcCpInfo = this.cf.getCpEntry(ldcIndex);
                if (!(ldcCpInfo instanceof StringCpInfo))
                {
                    ldcIndex = -1;
                }
            }
            else if ((opcode == 0x13) && ((i + 2) < this.code.length)) // ldc_w
            {
                ldcIndex = ((this.code[i + 1] & 0xFF) << 8) + (this.code[i + 2] & 0xFF);
                CpInfo ldcCpInfo = this.cf.getCpEntry(ldcIndex);
                if (!(ldcCpInfo instanceof StringCpInfo))
                {
                    ldcIndex = -1;
                }
            }
            if (((opcodePrev == 0x12) || (opcodePrev == 0x13)) && (ldcIndex != -1)) // ldc or ldc_w and is a StringCpInfo
            {
                boolean isClassForName = false;
                if ((opcode == 0xB8) && ((i + 2) < this.code.length)) // invokestatic
                {
                    int invokeIndex = ((this.code[i + 1] & 0xFF) << 8) + (this.code[i + 2] & 0xFF);
                    CpInfo cpInfo = this.cf.getCpEntry(invokeIndex);
                    if (cpInfo instanceof MethodrefCpInfo)
                    {
                        MethodrefCpInfo entry = (MethodrefCpInfo)cpInfo;
                        ClassCpInfo classEntry = (ClassCpInfo)this.cf.getCpEntry(entry.getClassIndex());
                        String className = this.cf.getUtf8(classEntry.getNameIndex());
                        NameAndTypeCpInfo ntEntry = (NameAndTypeCpInfo)this.cf.getCpEntry(entry.getNameAndTypeIndex());
                        String name = this.cf.getUtf8(ntEntry.getNameIndex());
                        String descriptor = this.cf.getUtf8(ntEntry.getDescriptorIndex());
                        if (("class$".equals(name) && ("(Ljava/lang/String;)Ljava/lang/Class;".equals(descriptor)
                            || "(Ljava/lang/String;Z)Ljava/lang/Class;".equals(descriptor)))
                            || ("java/lang/Class".equals(className) && "forName".equals(name)
                            && "(Ljava/lang/String;)Ljava/lang/Class;".equals(descriptor)))
                        {
                            isClassForName = true;
                            // Update StringCpInfo index in ldc to new one
                            Object o = cpUpdate.get(new Integer(ldcIndex));
                            if (o instanceof Integer)
                            {
                                Integer oi = (Integer)o;
                                int remapStringIndex = oi.intValue();
                                switch (opcodePrev)
                                {
                                    case 0x13: // ldc_w
                                        this.code[i - 2] = 0;
                                        //$FALL-THROUGH$
                                    case 0x12: // ldc
                                        this.code[i - 1] = (byte)remapStringIndex;
                                        break;
                                    default: // error
                                        throw new RuntimeException("Internal error: "
                                            + ".class or Class.forName remap of non-ldc/ldc_w");
                                }
                            }
                        }
                    }
                }
                if (cpToFlag != null)
                {
                    cpToFlag.updateFlag(this.cf.getCpEntry(ldcIndex), ldcIndex, isClassForName);
                }
            }
            int bytes = this.getOpcodeBytes(opcode, i);
            i += bytes;
            opcodePrev = opcode;
        }
        return cpToFlag;
    }

    /**
     * Compute length of opcode arguments at offset
     * 
     * @param opcode
     * @param i
     * @throws ClassFileException
     */
    private int getOpcodeBytes(int opcode, int i) throws ClassFileException
    {
        int bytes = CodeAttrInfo.opcodeBytes(opcode);
        if (bytes < 0) // variable length instructions
        {
            switch (opcode)
            {
                case 0xAA: // tableswitch
                    bytes = 3 - (i % 4); // 0-3 byte pad
                    bytes += 4; // default value
                    int low = ((this.code[i + 1 + bytes] & 0xFF) << 24) + ((this.code[i + 1 + bytes + 1] & 0xFF) << 16)
                        + ((this.code[i + 1 + bytes + 2] & 0xFF) << 8) + (this.code[i + 1 + bytes + 3] & 0xFF);
                    bytes += 4; // low value
                    int high = ((this.code[i + 1 + bytes] & 0xFF) << 24) + ((this.code[i + 1 + bytes + 1] & 0xFF) << 16)
                        + ((this.code[i + 1 + bytes + 2] & 0xFF) << 8) + (this.code[i + 1 + bytes + 3] & 0xFF);
                    bytes += 4; // high value
                    if (high >= low)
                    {
                        bytes += ((high - low) + 1) * 4; // jump offsets
                    }
                    break;
                case 0xAB: // lookupswitch
                    bytes = 3 - (i % 4); // 0-3 byte pad
                    bytes += 4; // default value
                    int npairs = ((this.code[i + 1 + bytes] & 0xFF) << 24) + ((this.code[i + 1 + bytes + 1] & 0xFF) << 16)
                        + ((this.code[i + 1 + bytes + 2] & 0xFF) << 8) + (this.code[i + 1 + bytes + 3] & 0xFF);
                    bytes += 4; // npairs value
                    if (npairs >= 0)
                    {
                        bytes += npairs * 8; // match / offset pairs
                    }
                    break;
                case 0xC4: // wide
                    int wideOpcode = this.code[i + 1] & 0xFF;
                    switch (wideOpcode)
                    {
                        case 0x15: // iload
                        case 0x16: // lload
                        case 0x17: // fload
                        case 0x18: // dload
                        case 0x19: // aload
                        case 0x36: // istore
                        case 0x37: // lstore
                        case 0x38: // fstore
                        case 0x39: // dstore
                        case 0x3A: // astore
                        case 0xA9: // ret
                            bytes = 3;
                            break;
                        case 0x84: // iinc
                            bytes = 5;
                            break;
                        default:
                            throw new ClassFileException("Illegal wide opcode");
                    }
                    break;
                default:
                    throw new ClassFileException("Illegal variable length opcode");
            }
        }
        return bytes;
    }

//    /**
//     * Convert int to 2 char hex string
//     * 
//     * @param i
//     */
//    private static String toHexString(int i)
//    {
//        String hex = "0" + Integer.toHexString(i);
//        return hex.substring(hex.length() - 2);
//    }
//
//    private static final String OPCODE_UNUSED = "<unused>";
//    private static final String OPCODE_RESERVED = "<reserved>";
//    private static final String[] opcodeName =
//    {
//        "nop", // 0x00
//        "aconst_null", // 0x01
//        "iconst_m1", // 0x02
//        "iconst_0", // 0x03
//        "iconst_1", // 0x04
//        "iconst_2", // 0x05
//        "iconst_3", // 0x06
//        "iconst_4", // 0x07
//        "iconst_5", // 0x08
//        "lconst_0", // 0x09
//        "lconst_1", // 0x0A
//        "fconst_0", // 0x0B
//        "fconst_1", // 0x0C
//        "fconst_2", // 0x0D
//        "dconst_0", // 0x0E
//        "dconst_1", // 0x0F
//        "bipush", // 0x10
//        "sipush", // 0x11
//        "ldc", // 0x12
//        "ldc_w", // 0x13
//        "ldc2_w", // 0x14
//        "iload", // 0x15
//        "lload", // 0x16
//        "fload", // 0x17
//        "dload", // 0x18
//        "aload", // 0x19
//        "iload_0", // 0x1A
//        "iload_1", // 0x1B
//        "iload_2", // 0x1C
//        "iload_3", // 0x1D
//        "lload_0", // 0x1E
//        "lload_1", // 0x1F
//        "lload_2", // 0x20
//        "lload_3", // 0x21
//        "fload_0", // 0x22
//        "fload_1", // 0x23
//        "fload_2", // 0x24
//        "fload_3", // 0x25
//        "dload_0", // 0x26
//        "dload_1", // 0x27
//        "dload_2", // 0x28
//        "dload_3", // 0x29
//        "aload_0", // 0x2A
//        "aload_1", // 0x2B
//        "aload_2", // 0x2C
//        "aload_3", // 0x2D
//        "iaload", // 0x2E
//        "laload", // 0x2F
//        "faload", // 0x30
//        "daload", // 0x31
//        "aaload", // 0x32
//        "baload", // 0x33
//        "caload", // 0x34
//        "saload", // 0x35
//        "istore", // 0x36
//        "lstore", // 0x37
//        "fstore", // 0x38
//        "dstore", // 0x39
//        "astore", // 0x3A
//        "istore_0", // 0x3B
//        "istore_1", // 0x3C
//        "istore_2", // 0x3D
//        "istore_3", // 0x3E
//        "lstore_0", // 0x3F
//        "lstore_1", // 0x40
//        "lstore_2", // 0x41
//        "lstore_3", // 0x42
//        "fstore_0", // 0x43
//        "fstore_1", // 0x44
//        "fstore_2", // 0x45
//        "fstore_3", // 0x46
//        "dstore_0", // 0x47
//        "dstore_1", // 0x48
//        "dstore_2", // 0x49
//        "dstore_3", // 0x4A
//        "astore_0", // 0x4B
//        "astore_1", // 0x4C
//        "astore_2", // 0x4D
//        "astore_3", // 0x4E
//        "iastore", // 0x4F
//        "lastore", // 0x50
//        "fastore", // 0x51
//        "dastore", // 0x52
//        "aastore", // 0x53
//        "bastore", // 0x54
//        "castore", // 0x55
//        "sastore", // 0x56
//        "pop", // 0x57
//        "pop2", // 0x58
//        "dup", // 0x59
//        "dup_x1", // 0x5A
//        "dup_x2", // 0x5B
//        "dup2", // 0x5C
//        "dup2_x1", // 0x5D
//        "dup2_x2", // 0x5E
//        "swap", // 0x5F
//        "iadd", // 0x60
//        "ladd", // 0x61
//        "fadd", // 0x62
//        "dadd", // 0x63
//        "isub", // 0x64
//        "lsub", // 0x65
//        "fsub", // 0x66
//        "dsub", // 0x67
//        "imul", // 0x68
//        "lmul", // 0x69
//        "fmul", // 0x6A
//        "dmul", // 0x6B
//        "idiv", // 0x6C
//        "ldiv", // 0x6D
//        "fdiv", // 0x6E
//        "ddiv", // 0x6F
//        "irem", // 0x70
//        "lrem", // 0x71
//        "frem", // 0x72
//        "drem", // 0x73
//        "ineg", // 0x74
//        "lneg", // 0x75
//        "fneg", // 0x76
//        "dneg", // 0x77
//        "ishl", // 0x78
//        "lshl", // 0x79
//        "ishr", // 0x7A
//        "lshr", // 0x7B
//        "iushr", // 0x7C
//        "lushr", // 0x7D
//        "iand", // 0x7E
//        "land", // 0x7F
//        "ior", // 0x80
//        "lor", // 0x81
//        "ixor", // 0x82
//        "lxor", // 0x83
//        "iinc", // 0x84
//        "i2l", // 0x85
//        "i2f", // 0x86
//        "i2d", // 0x87
//        "l2i", // 0x88
//        "l2f", // 0x89
//        "l2d", // 0x8A
//        "f2i", // 0x8B
//        "f2l", // 0x8C
//        "f2d", // 0x8D
//        "d2i", // 0x8E
//        "d2l", // 0x8F
//        "d2f", // 0x90
//        "i2b", // 0x91
//        "i2c", // 0x92
//        "i2s", // 0x93
//        "lcmp", // 0x94
//        "fcmpl", // 0x95
//        "fcmpg", // 0x96
//        "dcmpl", // 0x97
//        "dcmpg", // 0x98
//        "ifeq", // 0x99
//        "ifne", // 0x9A
//        "iflt", // 0x9B
//        "ifge", // 0x9C
//        "ifgt", // 0x9D
//        "ifle", // 0x9E
//        "if_icmpeq", // 0x9F
//        "if_icmpne", // 0xA0
//        "if_icmplt", // 0xA1
//        "if_icmpge", // 0xA2
//        "if_icmpgt", // 0xA3
//        "if_icmple", // 0xA4
//        "if_acmpeq", // 0xA5
//        "if_acmpne", // 0xA6
//        "goto", // 0xA7
//        "jsr", // 0xA8
//        "ret", // 0xA9
//        "tableswitch", // 0xAA
//        "lookupswitch", // 0xAB
//        "ireturn", // 0xAC
//        "lreturn", // 0xAD
//        "freturn", // 0xAE
//        "dreturn", // 0xAF
//        "areturn", // 0xB0
//        "return", // 0xB1
//        "getstatic", // 0xB2
//        "putstatic", // 0xB3
//        "getfield", // 0xB4
//        "putfield", // 0xB5
//        "invokevirtual", // 0xB6
//        "invokespecial", // 0xB7
//        "invokestatic", // 0xB8
//        "invokeinterface", // 0xB9
//        "invokedynamic", // 0xBA
//        "new", // 0xBB
//        "newarray", // 0xBC
//        "anewarray", // 0xBD
//        "arraylength", // 0xBE
//        "athrow", // 0xBF
//        "checkcast", // 0xC0
//        "instanceof", // 0xC1
//        "monitorenter", // 0xC2
//        "monitorexit", // 0xC3
//        "wide", // 0xC4
//        "multianewarray", // 0xC5
//        "ifnull", // 0xC6
//        "ifnonnull", // 0xC7
//        "goto_w", // 0xC8
//        "jsr_w", // 0xC9
//        CodeAttrInfo.OPCODE_RESERVED, // 0xCA
//        CodeAttrInfo.OPCODE_UNUSED, // 0xCB
//        CodeAttrInfo.OPCODE_UNUSED, // 0xCC
//        CodeAttrInfo.OPCODE_UNUSED, // 0xCD
//        CodeAttrInfo.OPCODE_UNUSED, // 0xCE
//        CodeAttrInfo.OPCODE_UNUSED, // 0xCF
//        CodeAttrInfo.OPCODE_UNUSED, // 0xD0
//        CodeAttrInfo.OPCODE_UNUSED, // 0xD1
//        CodeAttrInfo.OPCODE_UNUSED, // 0xD2
//        CodeAttrInfo.OPCODE_UNUSED, // 0xD3
//        CodeAttrInfo.OPCODE_UNUSED, // 0xD4
//        CodeAttrInfo.OPCODE_UNUSED, // 0xD5
//        CodeAttrInfo.OPCODE_UNUSED, // 0xD6
//        CodeAttrInfo.OPCODE_UNUSED, // 0xD7
//        CodeAttrInfo.OPCODE_UNUSED, // 0xD8
//        CodeAttrInfo.OPCODE_UNUSED, // 0xD9
//        CodeAttrInfo.OPCODE_UNUSED, // 0xDA
//        CodeAttrInfo.OPCODE_UNUSED, // 0xDB
//        CodeAttrInfo.OPCODE_UNUSED, // 0xDC
//        CodeAttrInfo.OPCODE_UNUSED, // 0xDD
//        CodeAttrInfo.OPCODE_UNUSED, // 0xDE
//        CodeAttrInfo.OPCODE_UNUSED, // 0xDF
//        CodeAttrInfo.OPCODE_UNUSED, // 0xE0
//        CodeAttrInfo.OPCODE_UNUSED, // 0xE1
//        CodeAttrInfo.OPCODE_UNUSED, // 0xE2
//        CodeAttrInfo.OPCODE_UNUSED, // 0xE3
//        CodeAttrInfo.OPCODE_UNUSED, // 0xE4
//        CodeAttrInfo.OPCODE_UNUSED, // 0xE5
//        CodeAttrInfo.OPCODE_UNUSED, // 0xE6
//        CodeAttrInfo.OPCODE_UNUSED, // 0xE7
//        CodeAttrInfo.OPCODE_UNUSED, // 0xE8
//        CodeAttrInfo.OPCODE_UNUSED, // 0xE9
//        CodeAttrInfo.OPCODE_UNUSED, // 0xEA
//        CodeAttrInfo.OPCODE_UNUSED, // 0xEB
//        CodeAttrInfo.OPCODE_UNUSED, // 0xEC
//        CodeAttrInfo.OPCODE_UNUSED, // 0xED
//        CodeAttrInfo.OPCODE_UNUSED, // 0xEE
//        CodeAttrInfo.OPCODE_UNUSED, // 0xEF
//        CodeAttrInfo.OPCODE_UNUSED, // 0xF0
//        CodeAttrInfo.OPCODE_UNUSED, // 0xF1
//        CodeAttrInfo.OPCODE_UNUSED, // 0xF2
//        CodeAttrInfo.OPCODE_UNUSED, // 0xF3
//        CodeAttrInfo.OPCODE_UNUSED, // 0xF4
//        CodeAttrInfo.OPCODE_UNUSED, // 0xF5
//        CodeAttrInfo.OPCODE_UNUSED, // 0xF6
//        CodeAttrInfo.OPCODE_UNUSED, // 0xF7
//        CodeAttrInfo.OPCODE_UNUSED, // 0xF8
//        CodeAttrInfo.OPCODE_UNUSED, // 0xF9
//        CodeAttrInfo.OPCODE_UNUSED, // 0xFA
//        CodeAttrInfo.OPCODE_UNUSED, // 0xFB
//        CodeAttrInfo.OPCODE_UNUSED, // 0xFC
//        CodeAttrInfo.OPCODE_UNUSED, // 0xFD
//        CodeAttrInfo.OPCODE_RESERVED, // 0xFE
//        CodeAttrInfo.OPCODE_RESERVED, // 0xFF
//    };
}
